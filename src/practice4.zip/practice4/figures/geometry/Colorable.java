package practice4.figures.geometry;

public interface Colorable {
    void howToColor();
}
